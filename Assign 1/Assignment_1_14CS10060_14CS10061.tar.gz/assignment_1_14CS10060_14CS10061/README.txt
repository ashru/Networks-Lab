1. assignment1_report.pdf is the report file.
2. The folder graph and net_plot contains the necessary plots and the scripts used to get them.
3. Readings.odt has the throughput readings of the different parts.
4. mytopo2.py is the python file to create a custom network.