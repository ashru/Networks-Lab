#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <dirent.h>
#include <netinet/in.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <errno.h>
#include <math.h>


const long long int STR_LENGTH = 1e5;
long long int size = 0;
long long int size_read = 0;
long long int size_written = 0;

// char *mystr;
// char *getstr;
// char *readstr;
void _write(int socket, char *s) {
	
	int x =strlen(s);
	write(socket, &x, sizeof(x));
	write(socket, s, x);
}

void _fget_write(int fd,  char *s) {
//   int x = s.length();
  if(s==NULL)
    return;
  int x = strlen(s);
  write(fd, &x, sizeof(x));
//   write(fd, s.c_str(), x);
  long long int y = write(fd, s, x);
  size_written += y;
}
void find_size(int fd){
	size = 0;
	int x;
	char buf[1024];
	while ((x = read(fd, buf, 1023)) > 0)
		size += x;

	

}

char* get_all(int fd) {
	char *getstr = NULL;
	getstr = (char *) malloc (sizeof(char) * STR_LENGTH);
	getstr[0]='\0';
	char buf[1024];
	int x;
	while ((x = read(fd, buf, 1023)) > 0) {
		buf[x] = '\0';
		strcat(getstr,buf);
	}
	return getstr;
}	

char* fget_get_all(int fd) {
    char * ans = NULL;
    ans = (char *)malloc(sizeof(char)*STR_LENGTH);
    ans[0]='\0';
    char buf[1024];
    int x;
    // while ((x = read(fd, buf, 128)) > 0) {
    //     buf[x] = '\0';
    //     // ans += string(buf);
    //     strcat(ans,buf);
    // }

    x = read(fd, buf, 1023);
    buf[x] = '\0';
    if(x>0){
        strcpy(ans,buf);
        return ans;
    }
    else
        return NULL;

    // return ans;
}

char* _read(int socket) {
	int len;
	// printf("here\n");
	
	char * readstr = NULL;
	readstr = (char *) malloc (sizeof(char) * STR_LENGTH);
	recv(socket, &len, sizeof(len), MSG_WAITALL);
	// printf("here2 %d\n",len);
	recv(socket, readstr, len, MSG_WAITALL);
	// printf("%s",readstr );
	readstr[len]='\0';
	size_read += len;
	return readstr;
}


void handler(int s) {
	int saved_errno = errno;
	while(waitpid(-1, NULL, WNOHANG) > 0);
	errno = saved_errno;
}

int main(int argc, char *argv[]) {
	int choice;
	struct sigaction sa;
	char * mystr = NULL;
	mystr = (char *) malloc (sizeof(char) * STR_LENGTH);
	sa.sa_handler = handler;
	sigemptyset(&sa.sa_mask);
	sa.sa_flags = SA_RESTART;
	
	if(sigaction(SIGCHLD, &sa, NULL)<0)
	{
		perror("SIGACTION:");
		exit(0);
	}
	int server_port = 11000;
	int init_socket;
	
	if((init_socket=socket(PF_INET, SOCK_STREAM, 0))<0)
	{
		perror("SOCKET:");
		exit(0);
	}

	struct sockaddr_in serv;
	bzero(&serv, sizeof(serv));
	serv.sin_family = AF_INET;
	serv.sin_port = htons(server_port);
	serv.sin_addr.s_addr = INADDR_ANY;
	int iSetOption = 1;
    setsockopt(init_socket, SOL_SOCKET, SO_REUSEADDR, (char*)&iSetOption, sizeof(iSetOption));
    
	if(bind(init_socket, (struct sockaddr *)&serv, sizeof(serv))<0)
	{
		perror("BIND:");
		exit(0);
	}

	
	if(listen(init_socket,5)<0)
	{
		perror("LISTEN:");
		exit(0);
	}
	while (1) {
		struct sockaddr_in client;
		socklen_t client_sz = sizeof(client);
		int message_socket;
		
		if((message_socket = accept(init_socket, (struct sockaddr *)&client, &client_sz))<0)
		{
			perror("ACCEPT:");
			exit(0);
		}
		int pid;
		
		if((pid=fork()) < 0)
		{
			perror("FORK:");
			exit(0);
		}
		if (pid == 0) {
			close(init_socket);
			int data_socket;
			
			if((data_socket = socket(PF_INET, SOCK_STREAM, 0)) <0)
			{
				perror("SOCKET:");
				exit(0);
			}

			struct sockaddr_in client2;
			bzero(&client2, sizeof(client2));
			char client_ip[100];
			inet_ntop(AF_INET, &client.sin_addr, client_ip, sizeof(client_ip));
			client2.sin_family = AF_INET;
			client2.sin_addr.s_addr = inet_addr(client_ip);
			



			while(strcmp(_read(message_socket),"setport") != 0) ;
			int port_to_receive;
			int r_s;
			int new_port;
			while(1){
				r_s = read(message_socket, &port_to_receive, sizeof(port_to_receive));
				if (r_s > 0) {
					new_port = ntohl(port_to_receive);
					break;
				}
				
			}
			printf("New port = %d\n",new_port);


			// client2.sin_port = htons(11001);
			client2.sin_port = htons(new_port);
			








			if(connect(data_socket, (struct sockaddr *)&client2, sizeof(client2))<0)
			{
				perror("CONNECT:");
				exit(0);
			}
			while (1) {
				size = size_read = size_written = 0;
				char cmd[1000];
				// char * readstr = _read(message_socket);
				strcpy(cmd,_read(message_socket));
				printf("cmd = %s\n",cmd );
				if (!strcmp(cmd,"pwd")) {
				
					choice = 1;
					
				}
				else if (!strcmp(cmd,"quit")) {
					
					break;
				}
				else if (!strcmp(cmd,"ls")) {
					choice = 2;
					 
				}
				else if (!strcmp(cmd,"fput")) {
					choice = 3;
					
						
				}
				else if (!strcmp(cmd,"fget")) {
					choice = 4;
					
				}
				else {
					continue;
				}
				switch (choice){
					case 1:
						{
							strcat(cmd, " 2>&1");
							FILE * console = popen(cmd, "r");
							// get_all(fileno(console));
							_write(data_socket, get_all(fileno(console)));
							pclose(console);
						}
						break;
					case 2:
						{
							strcat(cmd, " 2>&1");
							printf("ls\n");
							FILE * console = popen(cmd, "r");
							// get_all(fileno(console));
							_write(data_socket, get_all(fileno(console)));
							pclose(console);
						}
						break;
					case 3:
						{
							char filename[1000];
					
							strcpy(filename,_read(message_socket));
							while(strcmp(_read(message_socket),"setsize") != 0) ;

							long long int size_to_receive;
							long long int return_status;
							while(1){
								return_status = read(message_socket, &size_to_receive, sizeof(size_to_receive));
								if (return_status > 0) {
									size = ntohl(size_to_receive);
									break;
								}
								
							}
							


							char *data = (char *) malloc (sizeof(char) * STR_LENGTH);
							// int fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, S_IRWXU);
							FILE *fp = fopen(filename,"w+");
							if (fp == NULL) {
								_write(message_socket, strerror(errno));
							}
							
							while(size_read < size){
								strcpy(data,_read(data_socket));
								
								
								fwrite(data , 1 , strlen(data) , fp);	
								
							}
							
							fclose(fp);
							_write(message_socket, "File uploaded successfully.\n");
						}
						break;
					case 4:
						{
							char filename[1000];
							strcpy(filename,_read(message_socket));
							int fd;
							fd = open(filename, O_RDONLY);
							

							if (fd == -1) {
								_write(message_socket, strerror(errno));
							}
							else {
							
								find_size(fd);
								close(fd);
								
								_write(message_socket, "setsize");
								long long int size_to_send = htonl(size);
								write(message_socket, &size_to_send, sizeof(size_to_send));

								fd = open(filename, O_RDONLY);

								while(size_written < size){
									_fget_write(data_socket, fget_get_all(fd));

								}
								
								_write(message_socket, "File downloaded successfully.\n");
								close(fd);
							}
						}
						break;
				}
			}
			close(data_socket);
			close(message_socket);
			exit(0);
		}
		else {
			close(message_socket);
		}
	}

	close(init_socket);
	printf("Done\n");
	return 0;
}