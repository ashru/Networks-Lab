#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <dirent.h>
#include <netinet/in.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <strings.h>
#include <string.h>
#include <errno.h>

const long long int STR_LENGTH = 1e5;
long long int size = 0;
long long int size_written = 0;
long long int size_read = 0;

// void _write(int fd, const string &s) {
void _write(int fd,  char *s) {
//   int x = s.length();
  if(s==NULL)
    return;
  int x = strlen(s);
  write(fd, &x, sizeof(x));
//   write(fd, s.c_str(), x);
  long long int y = write(fd, s, x);
  size_written += y;
}

// string get_all(int fd) {
char* get_all(int fd) {
    char * ans = NULL;
    ans = (char *)malloc(sizeof(char)*STR_LENGTH);
    ans[0]='\0';
    char buf[1024];
    int x;
    // while ((x = read(fd, buf, 128)) > 0) {
    //     buf[x] = '\0';
    //     // ans += string(buf);
    //     strcat(ans,buf);
    // }

    x = read(fd, buf, 1023);
    buf[x] = '\0';
    if(x>0){
        strcpy(ans,buf);
        return ans;
    }
    else
        return NULL;

    // return ans;
}

char* _read(int fd) {
  int len;
  while(read(fd, &len, sizeof(int)) != sizeof(int));  // write int is atomic
  char * ans = NULL;
  ans = (char *)malloc(sizeof(char)*STR_LENGTH);
  ans[0]='\0';

  char buf[len+1];
  int x;
  while ((x = read(fd, buf, len)) && len) {
    
    len -= x;
    buf[x] = '\0';
    
    strcat(ans,buf);
  }
  return ans;
}

char* _fget_read(int socket) {
	int len;
	

	char * readstr = NULL;
	readstr = (char *) malloc (sizeof(char) * STR_LENGTH);
	recv(socket, &len, sizeof(len), MSG_WAITALL);
	
	recv(socket, readstr, len, MSG_WAITALL);
	
	readstr[len]='\0';
	size_read += len;
	return readstr;
}

char* _read_socket(int socket) {
	int len;
	

	char * readstr = NULL;
	readstr = (char *) malloc (sizeof(char) * STR_LENGTH);
	recv(socket, &len, sizeof(len), MSG_WAITALL);
	recv(socket, readstr, len, MSG_WAITALL);
	readstr[len]='\0';
	return readstr;
}



void find_size(int fd){
	size = 0;
	int x;
	char buf[1024];
	while ((x = read(fd, buf, 1023)) > 0)
		size += x;

	

}

int main(int argc, char* argv[]){
    int i;
    if (argc != 4) {
        printf("Invalid arguments\n");
        exit(-1);
    }


    struct sockaddr_in server;
    bzero(&server, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = htons(atoi(argv[2]));
    server.sin_addr.s_addr = inet_addr(argv[1]);
  

    int message_socket;
    if ((message_socket = socket(PF_INET, SOCK_STREAM, 0)) < 0){
        perror ("Error in socket()");
        exit(1);
    }

    if (connect(message_socket, (struct sockaddr *)&server, sizeof(server)) < 0){
        perror("Error in connect");
        exit(1);
    }


    
    int client_port = atoi(argv[3]);



    _write(message_socket, "setport");
	int port_to_send = htonl(client_port);
	write(message_socket, &port_to_send, sizeof(port_to_send));



    int init_socket;

    if((init_socket = socket(PF_INET, SOCK_STREAM, 0)) < 0){
        perror("Error in init socket");
        exit(1);
    }
    
    struct sockaddr_in client;
    bzero(&client, sizeof(client));
    client.sin_family = AF_INET;
    client.sin_port = htons(client_port);
    client.sin_addr.s_addr = INADDR_ANY;

    int iSetOption = 1;
    setsockopt(init_socket, SOL_SOCKET, SO_REUSEADDR, (char*)&iSetOption, sizeof(iSetOption));
    if(bind(init_socket, (struct sockaddr *)&client, sizeof(client)) < 0){
        perror("Error in bind");
        exit(1);
    }


    if(listen(init_socket, 5) < 0){
        perror("Error in listen");
        exit(1);
    }
    
    int data_socket;
    struct sockaddr_in server2;
    socklen_t server2_sz;

    if((data_socket = accept(init_socket, (struct sockaddr *)&server2, &server2_sz)) < 0){
        perror("Error in accept");
        exit(1);
    }
    

    char cmd[1024];
        
    
    while(1){
    	size = size_written = size_read = 0;
        printf("myftp> ");
        fgets (cmd, 1023, stdin);

        cmd[strlen(cmd)-1] = '\0';
        if(strlen(cmd)==0){
        	continue;
        }
        int choice;
        if(strcmp(cmd,"servpwd")==0){
        	choice=0;
            
            
        }

        else if(strcmp(cmd,"quit")==0){
        	choice=1;
            
        }
        else if(strcmp(cmd,"servls")==0){
        	choice=2;
           
			
        }
        
        else if(strcmp(cmd,"clipwd")==0){
        	choice=3;       
        }
        else if(strcmp(cmd,"clils")==0){
        	choice=4;

        }
        else if(strncmp("fput", cmd, strlen("fput")) == 0){
        	choice=5;
            
            
        }
        
        else if(strncmp("fget", cmd, strlen("fget")) == 0){
        	choice=6;           
        }

        else{
        	choice=7;
            
        }
        switch(choice)
        {
        case 0:
        _write(message_socket, "pwd");
            printf("%s\n",_read(data_socket));
        break;
        case 1:
        _write(message_socket, "quit");
			return 0;
        break;
        case 2:
         _write(message_socket, "ls");
            printf("%s\n",_read(data_socket));
        break;
        case 3:
        {
        FILE * console = popen("pwd 2>&1", "r");
			
            printf("%s\n",get_all(fileno(console)));
        }
        break;
        case 4:
        {
         FILE * console = popen("ls 2>&1", "r");
		
            printf("%s\n",get_all(fileno(console)));
        }
        break;
        case 5:
        {
        char filename[1023];
			
			
            if (cmd[4]!=' '){
            	printf("Invalid command\n");
            	continue;
            }
            
            for(i=5;cmd[i]!='\0';i++){
            	filename[i-5] = cmd[i];
            }
            filename[i-5] = '\0';

            
            int fd = open(filename, O_RDONLY);
			if (fd < 0) {
				perror("open");
				close(fd);
				continue;
			}
			_write(message_socket, "fput");
			_write(message_socket, filename);
			find_size(fd);

			_write(message_socket, "setsize");
			long long int size_to_send = htonl(size);
			write(message_socket, &size_to_send, sizeof(size_to_send));


			close(fd);
			fd = open(filename, O_RDONLY);
			while(size_written < size){
                _write(data_socket, get_all(fd));
                
			}
			
			printf("%s\n",_read_socket(message_socket));
			close(fd);
		}
        break;
        case 6:
        {
        char filename[1023];



            if (cmd[4]!=' '){
            	printf("Invalid command\n");
            	continue;
            }
           
            for(i=5;cmd[i]!='\0';i++){
            	filename[i-5] = cmd[i];
            }
            filename[i-5] = '\0';



			_write(message_socket, "fget");
			_write(message_socket, filename);
			

			while(strcmp(_read(message_socket),"setsize") != 0) ;
			long long int size_to_receive;
			long long int return_status;
			while(1){
				return_status = read(message_socket, &size_to_receive, sizeof(size_to_receive));
				if (return_status > 0) {
					size = ntohl(size_to_receive);
					break;
				}
				
			}
			


            char *data = (char *) malloc (sizeof(char) * STR_LENGTH);
            data[0] = '\0';
            


			FILE *fp = fopen(filename,"w+");
			if (fp == NULL) {
				_write(message_socket, strerror(errno));
			}
			
			while(size_read < size){
				strcpy(data,_fget_read(data_socket));
				
				fwrite(data , 1 , strlen(data) , fp);	
				
			}


			fclose(fp);
			printf("%s\n",_read(message_socket));
		}
        break;
        case 7:
        printf("An invalid FTP command\n");
        break;
    }

        
    }




    close(init_socket);
    close(data_socket);
    close(message_socket);

    return 0;
}