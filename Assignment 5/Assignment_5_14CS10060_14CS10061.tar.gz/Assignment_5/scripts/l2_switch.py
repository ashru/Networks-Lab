
from pox.lib.util import dpidToStr
import pox.openflow.libopenflow_01 as opf      # OpenFlow 1.0 library
from pox.lib.addresses import EthAddr, IPAddr # Address types
import pox.lib.recoco as recoco
from pox.lib.revent import *

from pox.lib.packet import arp, ethernet
from pox.core import core  

# Create a logger 
log = core.getLogger()
HARD_TIMEOUT=30
IDLE_TIMEOUT=30
class Switch(EventMixin):
  def __init__(self):
    self.listenTo(core.openflow)
  def _handle_ConnectionUp (self, event):
    l2_switch(event.connection)


class l2_switch(EventMixin):
  def __init__(self,connection):
    self.connection=connection
    self.mac_to_port={}
    self.listenTo(connection)


  def packet_send (self, buffer_id, raw_data, out_port, in_port):
    """
    Sends a packet out of the specified switch port.
    If buffer_id is a valid buffer on the switch, use that.  Otherwise,
    send the raw data in raw_data.
    The "in_port" is the port number that packet arrived on.  Use
    OFPP_NONE if you're generating this packet.
    """
    msg = opf.ofp_packet_out()
    msg.in_port = in_port
    if buffer_id != -1 and buffer_id is not None:
      # We got a buffer ID from the switch; use that
      msg.buffer_id = buffer_id
    else:
      # No buffer ID from switch -- we got the raw data
      if raw_data is None:
        # No raw_data specified -- nothing to send!
        return
      msg.data = raw_data

    # Add an action to send to the specified port
    action = opf.ofp_action_output(port = out_port)
    msg.actions.append(action)

    # Send message to switch
    self.connection.send(msg)


  def _handle_PacketIn (self, event):
  # parsing the input packet
    packet = event.parse()
    packet_in=event.ofp
    # updating out mac to port mapping
    self.mac_to_port[packet.src] = event.port
    # set destination
    destination=self.mac_to_port.get(packet.dst)

    if destination is None:
      self.packet_send(packet_in.buffer_id, packet_in.data, opf.OFPP_FLOOD, packet_in.in_port)
    else:
      self.packet_send(packet_in.buffer_id, packet_in.data, destination, packet_in.in_port)



    msg = opf.ofp_flow_mod()
    msg.match.dl_src = packet.dst
    msg.match.dl_dst = packet.src
    msg.idle_timeout = IDLE_TIMEOUT
    msg.hard_timeout = HARD_TIMEOUT
    msg.actions.append(opf.ofp_action_output(port = event.port))
    self.connection.send(msg)





class learning_switch (EventMixin):

  def __init__(self):
    self.listenTo(core.openflow)

  def _handle_ConnectionUp (self, event):
    l2_switch(event.connection)


def launch ():
  #Starts an L2 learning switch.
  core.registerNew(learning_switch)

