

from pox.core import core
import pox
log = core.getLogger()

from pox.lib.packet.ethernet import ethernet, ETHER_BROADCAST
from pox.lib.packet.ipv4 import ipv4
from pox.lib.packet.arp import arp
from pox.lib.addresses import IPAddr, EthAddr
from pox.lib.util import str_to_bool, dpid_to_str
from pox.lib.recoco import Timer

import pox.openflow.libopenflow_01 as of

from pox.lib.revent import *

import time
import json

HARD_TOUT=50
IDLE_TOUT=50

routing_table = {}

def dpid_to_mac (dpid):
  return EthAddr("%012x" % (dpid & 0xffFFffFFffFF,))

class Router(EventMixin):
  def __init__(self):
    self.listenTo(core.openflow)

  def _handle_ConnectionUp (self, event):
    l3_switch(event.connection)

  def _handle_ConnectionDown(self, event):
    routing_table = {}

class l3_switch(EventMixin):
  def __init__(self,connection):

    dpid = connection.dpid
    
    self.connection=connection

   
    self.lost_buffers = {}

   
    self.mac_to_ip={}

   
    config = json.loads(open('config.json').read())
    for datapath_id in config:
      for d_id in datapath_id.keys():
        d_id = d_id.encode('ascii', 'ignore')
        if int(d_id) == dpid:
          routing_table[dpid] = {}  
          for row in datapath_id[d_id]:
            data = datapath_id[d_id][row]
            dest = data["destination"].encode('ascii', 'ignore')
            routing_table[dpid][dest] = []
            routing_table[dpid][dest].append(data["next_hop"].encode('ascii', 'ignore'))
            routing_table[dpid][dest].append(data["interface"].encode('ascii', 'ignore'))

    self.listenTo(connection)
  
  def _send_lost_buffers (self, dpid, ipaddr, macaddr, port,xe,xc):
    if (dpid,ipaddr) in self.lost_buffers:
      bucket = self.lost_buffers[(dpid,ipaddr)]
      del self.lost_buffers[(dpid,ipaddr)]
      for buffer_id,in_port in bucket:
        po = of.ofp_packet_out(buffer_id=buffer_id,in_port=in_port)
        po.actions.append(of.ofp_action_dl_addr.set_dst(macaddr))
        po.actions.append(of.ofp_action_output(port = port))
        core.openflow.sendToDPID(dpid, po)  

  def _handle_PacketIn (self, event):
    dpid = event.connection.dpid
    src_in = event.port
    packet = event.parsed

    # Ignore LLDP packets
    if packet.type == ethernet.LLDP_TYPE:
      return

    if isinstance(packet.next, arp):
      # ARP packet
      a = packet.next
      src_in = event.port

      if a.prototype == arp.PROTO_TYPE_IP:
        if a.hwtype == arp.HW_TYPE_ETHERNET:
          if a.protosrc != 0:
            if a.protosrc in self.mac_to_ip:
             pass
            else:
             
              self.mac_to_ip[a.protosrc] = a.hwsrc
            xe = 1
            xc = 1
            self._send_lost_buffers(dpid, a.protosrc, packet.src, src_in,xe,xc)       

            if a.opcode == arp.REQUEST:
              if a.protodst in self.mac_to_ip or a.hwdst == EthAddr("00:00:00:00:00:00"):
                test(event,src_in,a,packet,dpid)
                return
    


    else:         
      src_in = event.port
      xe = 1
      xc = 1
      self._send_lost_buffers(dpid, packet.next.srcip, packet.src, src_in,xe,xc)          
      

      if packet.next.srcip in self.mac_to_ip:
        pass
      else:
        self.mac_to_ip[packet.next.srcip] = packet.src

      dstaddr = packet.next.dstip
      self.test3(dstaddr,dpid,event,src_in,packet)




  def test3(self,dstaddr,dpid,event,src_in,packet):
    if dstaddr in self.mac_to_ip:
      prt = int(routing_table[dpid][str(dstaddr)][1])
      mac = self.mac_to_ip[dstaddr]
      actions = []
      actions.append(of.ofp_action_dl_addr.set_dst(mac))
      actions.append(of.ofp_action_output(port = prt))
      match = of.ofp_match.from_packet(packet, src_in)
      match.dl_src = None
      match.dl_dst = mac;

      msg = of.ofp_flow_mod(command=of.OFPFC_ADD,idle_timeout=10,hard_timeout=of.OFP_FLOW_PERMANENT,buffer_id=event.ofp.buffer_id,actions=actions,match=match)

      event.connection.send(msg)
    else:
      if (dpid,dstaddr) not in self.lost_buffers:
        self.lost_buffers[(dpid,dstaddr)] = []
      bucket = self.lost_buffers[(dpid,dstaddr)]
      entry = (event.ofp.buffer_id,src_in)
      bucket.append(entry)


      msg = test2(packet,dstaddr,src_in)
      event.connection.send(msg)


def launch ():
  core.registerNew(Router)





def test2(packet,dstaddr,src_in):
  r = arp()
  r.hwtype = r.HW_TYPE_ETHERNET
  r.prototype = r.PROTO_TYPE_IP
  r.hwlen = 6
  r.protolen = r.protolen
  r.opcode = r.REQUEST
  r.hwdst = ETHER_BROADCAST
  r.protodst = dstaddr
  r.hwsrc = packet.src
  r.protosrc = packet.next.srcip
  e = ethernet(type=ethernet.ARP_TYPE, src=packet.src,
               dst=ETHER_BROADCAST)
  e.set_payload(r)
  msg = of.ofp_packet_out()
  msg.data = e.pack()
  msg.actions.append(of.ofp_action_output(port = of.OFPP_FLOOD))
  msg.in_port = src_in
  
  return msg



def test(event,src_in,a,packet,dpid):
  # send ARP packet
  r = arp()
  r.hwtype = a.hwtype
  r.prototype = a.prototype
  r.hwlen = a.hwlen
  r.protolen = a.protolen
  r.opcode = arp.REPLY
  r.hwdst = a.hwsrc
  r.protodst = a.protosrc
  r.protosrc = a.protodst
  for entry in event.connection.ports.values():
    port = entry.port_no
    if port == src_in:  
      mac = entry.hw_addr
  
  r.hwsrc = mac
  e = ethernet(type=packet.type, src=dpid_to_mac(dpid),
               dst=a.hwsrc)
  e.set_payload(r)
 
  msg = of.ofp_packet_out()
  msg.data = e.pack()
  msg.actions.append(of.ofp_action_output(port = of.OFPP_IN_PORT))
  msg.in_port = src_in
  event.connection.send(msg)