from mininet.net import Mininet
from mininet.node import Controller, RemoteController, OVSController
from mininet.node import CPULimitedHost, Host, Node
from mininet.node import OVSKernelSwitch, UserSwitch
from mininet.node import IVSSwitch
from mininet.cli import CLI
from mininet.log import setLogLevel, info
from mininet.link import TCLink, Intf
from subprocess import call


def new_network():
    net = Mininet(topo=None, build=False, ipBase='10.0.0.0/8')

    info('Adding controller : \n')

    c_l2 = net.addController(name='c_l2', controller=RemoteController, ip='127.0.0.1', protocol='tcp', port=6644)
    c_l3 = net.addController(name='c_l3', controller=RemoteController, ip='127.0.0.1', protocol='tcp', port=6655)
    
    info('Add switches : \n')

    h1 = net.addHost( 'h1', ip = "172.16.0.2", defaultRoute = "via 172.16.0.1" )
    h2 = net.addHost( 'h2', ip = "192.168.1.2", defaultRoute = "via 192.168.1.1" )
    h3 = net.addHost( 'h3', ip = "10.2.0.2", defaultRoute = "via 10.2.0.1" )
#    h4 = net.addHost( 'h4', ip = "10.3.0.2", defaultRoute = "via 10.3.0.1" )
#    h5 = net.addHost( 'h5', ip = "10.2.0.4", defaultRoute = "via 10.2.0.1" )
    r1 = net.addSwitch( 'r1' )
#    r2 = net.addSwitch( 'r2' )
    s1 = net.addSwitch( 's1' ) 
    s2 = net.addSwitch( 's2' )
    s3 = net.addSwitch( 's3' ) 
    s4 = net.addSwitch( 's4' ) 
    s5 = net.addSwitch( 's5' ) 
    s6 = net.addSwitch( 's6' ) 
    s7 = net.addSwitch( 's7' ) 
    s8 = net.addSwitch( 's8' ) 
    s9 = net.addSwitch( 's9' ) 




    net.addLink(h1, s1)
    net.addLink(s1, s2)
    net.addLink(s1, s3)
    net.addLink(s2, s3)
    net.addLink(s2, s4)
    net.addLink(s3, s5)
    net.addLink(s5, s4)
    net.addLink(s5, s6)
    net.addLink(s6, s4)
    net.addLink(r1, s6)
    net.addLink(r1, s7)
    net.addLink(r1, s8)
    net.addLink(s7, h2)
    net.addLink(h3, s8)
    
    
    

    info('Starting network : \n')
    net.build()
    info('Starting controllers : \n')
    for c in net.controllers:
        c.start()

    info('Starting switches : \n')
    net.get('s2').start([c_l2])
    net.get('s1').start([c_l2])
    net.get('s3').start([c_l2])
    net.get('s4').start([c_l2])
    net.get('s5').start([c_l2])
    net.get('s6').start([c_l2])
    net.get('s7').start([c_l2])
    net.get('s8').start([c_l2])
    net.get('s9').start([c_l2])
    net.get('r1').start([c_l3])
    

    info('Post configure switches and hosts : \n')

    CLI(net)
    net.stop()


def main():
    setLogLevel( 'info' )
    new_network()

if __name__ == '__main__':
    main()